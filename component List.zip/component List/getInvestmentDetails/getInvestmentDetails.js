import { LightningElement,api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

const columns = [
    { label: 'Fund Name', fieldName: 'Fund Name' },
    { label: 'Fund Value', fieldName: 'Fund Value' },
];

const creditcolumns = [
    { label: 'Card', fieldName: 'Card' },
    { label: 'Limit', fieldName: 'Limit' },
];

const loanColumns = [
    { label: 'Loan Type', fieldName: 'Loan Type' },
    { label: 'Loan Amount', fieldName: 'Loan Amount' },
];

export default class GetInvestmentDetails extends LightningElement {
    //make api call out to get investment profile

    columns = columns;
    data = [{
        'Fund Name':'AXIS',
        'Fund Value':'1000000'
        }]

    creditcolumns = creditcolumns;
    creditdata = [{
        'Card':'ICICI Coral',
        'Limit':'100000'
        }]

        loanColumns = loanColumns;
        loanData = [{
            'Loan Type':'Personal Loan',
            'Loan Amount':'500000'
            }]
    

}