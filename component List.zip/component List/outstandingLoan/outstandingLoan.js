import { LightningElement } from 'lwc';

const columns = [
    { label: 'Loan Type', fieldName: 'Loan Type' },
    { label: 'Loan Amount', fieldName: 'Loan Amount' },
];

export default class OutstandingLoan extends LightningElement {

    columns = columns;
    data = [{
        'Loan Type':'Personla Loan',
        'Loan Amount':'1000000'
        }]

}