import { LightningElement } from 'lwc';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import PHONE_FIELD from '@salesforce/schema/Account.phone';
import SALARY_FIELD from '@salesforce/schema/Account.Salary__c';

export default class AccountDetails extends LightningElement {
    fields = [NAME_FIELD,SALARY_FIELD,PHONE_FIELD];
}