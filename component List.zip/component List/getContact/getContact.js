import { LightningElement } from 'lwc';
import NAME_FIELD from '@salesforce/schema/Contact.Name';
import EMAIL_FIELD from '@salesforce/schema/Contact.email';
import Acc_FIELD from '@salesforce/schema/Contact.AccountId';



export default class GetContact extends LightningElement {
    fields = [Acc_FIELD,NAME_FIELD,EMAIL_FIELD];
}

